package com.indecomm.dto;

public class AutomationDTO 
{
     
}
