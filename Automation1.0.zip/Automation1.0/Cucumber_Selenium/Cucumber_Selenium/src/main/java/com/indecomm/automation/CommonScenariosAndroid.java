package com.indecomm.automation;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.indecomm.fixtures.IOSAutomationFixture;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;


public class CommonScenariosAndroid  {
	 	 
	AppiumDriver driver;
	ElementRepository elementRepository;
	String propetyPath;
	
	 public  CommonScenariosAndroid(AppiumDriver<MobileElement> driver) {
		 		//super(driver);
		 		this.driver = driver;
				System.out.println(":: Start redirecting on login page ::");
				propetyPath = System.getProperty("user.dir") + "/" + "feedFiles/locator.properties";
				elementRepository = new ElementRepository(propetyPath);
				//System.out.println(elementRepository.getPropertyByTag("textWithName"));
				//PageFactory.initElements(new AppiumFieldDecorator(driver), this);		
	
		
	}
	 
	public void AndroidLogin(String platform) throws InterruptedException {
		//new AbstractScenarios(this.driver).AppLogin(platform);
		

		/*
		 * Click on Continue button to redirect loginpage
		 */
		System.out.println(":: ENTER IN LOGINPAGE ::");
		
		Thread.sleep(5000);
		System.out.println("***************");
		System.out.println(this.driver);
		System.out.println(this.driver.getPageSource());
		System.out.println("*****************");
		/*System.out.println("App launched");
		WebElement addContactButton = (WebElement) this.driver.findElementsByAccessibilityId("Add Contact");
		addContactButton.click();
		 List<MobileElement>textFields = this.driver.findElements(By.className("android.widget.EditText"));
		textFields.get(0).sendKeys("Neeraj Test");

		textFields.get(1).sendKeys("9999999999");
		textFields.get(2).sendKeys("testemail@domain.com");

		this.driver.findElement(By.name("Save")).click();
		*/
		//WebDriverWait wait1= new WebDriverWait(driver,10);
		//WebElement ele= wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//[@text='Get Started']")));
		//ele.click();
		//((Object) this.driver).pressKeyCode(AndroidKeyCode.BACK);
		this.driver.findElement(By.id("com.microsoft.office.outlook:id/btn_splash_start")).click();

	    this.driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	    
	    
		//MobileElement mn =  this.driver.findElementById("com.microsoft.office.outlook:id/btn_splash_start");
		//mn.click();
		
		//System.out.println(this.driver.findElement(By.xpath("//*[@text=\"Get Started\" and @class=\"android.widget.Button\"]")));
		
		//this.driver.findElement(By.xpath("//*[@text=\"Get Started\"] and @class=\"android.widget.Button\"]")).click();
		
		//System.out.println(this.driver.findElement(By.xpath("//*[@text=\"Get Started\" and @class=\"android.widget.Button\"]")));
	
		Thread.sleep(6000);
		
			
	}
	
	public void TestAppRegitration(String platform) throws InterruptedException {
		//new AbstractScenarios(this.driver).AppLogin(platform);
		/*
		 * Click on Continue button to redirect loginpage
		 */
		System.out.println(":: START SCENARIO ::");
		
		Thread.sleep(5000);
		System.out.println("*************** Start Registration Senario To test ***************");
		System.out.println(elementRepository.getPropertyByTag("not_reg"));
		
			MobileElement noRegiBtn = (MobileElement) this.driver.findElementById(elementRepository.getPropertyByTag("not_reg"));
			noRegiBtn.click();
			
			MobileElement editNametxt = (MobileElement) this.driver.findElementById(elementRepository.getPropertyByTag("editName"));
			editNametxt.sendKeys("Navjot");
			
			MobileElement editUserNameTxt = (MobileElement) this.driver.findElementById(elementRepository.getPropertyByTag("editUserName"));
			editUserNameTxt.sendKeys("Navjot");
			
			MobileElement editPasswordTxt = (MobileElement) this.driver.findElementById(elementRepository.getPropertyByTag("editPassword"));
			editPasswordTxt.sendKeys("test123");
			
			MobileElement editconfirmpasswordTxt = (MobileElement) this.driver.findElementById(elementRepository.getPropertyByTag("editconfirmpassword"));
			editconfirmpasswordTxt.sendKeys("test123");
			
			MobileElement btnSaveBtn = (MobileElement) this.driver.findElementById(elementRepository.getPropertyByTag("btnSave"));
			btnSaveBtn.click();
		
		System.out.println("*************** Done Registration ***************");
		
		Thread.sleep(6000);
			
	}
	
}
